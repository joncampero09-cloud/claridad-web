# Claridad — web MVP

Este repositorio contiene una primera versión de Claridad preparada para desplegarse en Vercel.

## Estructura
- `public/index.html`: aplicación web.
- `public/posts.json`: contenido y categorías.
- `api/ai.js`: función de servidor que llama a Anthropic sin exponer la clave al navegador.
- `vercel.json`: rutas de estáticos y función API.
- `.gitignore`: evita subir credenciales y archivos locales.

## Publicación con GitHub + Vercel
1. En GitHub, crea un repositorio privado llamado `claridad-web`.
2. Sube **el contenido de esta carpeta** a la raíz del repositorio, de modo que `public`, `api`, `package.json` y `vercel.json` queden en la raíz (no anides otra carpeta `claridad-web`).
3. En Vercel, importa el repositorio.
4. Configuración recomendada: Framework Preset `Other`; Root Directory `./`; Build Command vacío; Output Directory vacío (la configuración `vercel.json` define las rutas).
5. En Vercel → Project → Settings → Environment Variables añade:
   - `ANTHROPIC_API_KEY`: tu clave de Anthropic, como variable sensible.
   - `DAILY_LIMIT`: `30` (opcional; límite aproximado en memoria, no un límite de facturación).
   - `MODEL`: un identificador de modelo de Anthropic que esté habilitado para tu clave.
6. Haz un nuevo deployment y prueba primero la biblioteca y después un ejercicio de IA.

## Importante sobre seguridad y límites
- No pongas claves de API en HTML, en `posts.json`, en GitHub ni en mensajes.
- El límite diario en memoria de `api/ai.js` es solo aproximado: puede reiniciarse al escalar o reiniciar funciones. No sirve como protección fiable contra abuso o gasto.
- La función espera que Anthropic devuelva una respuesta de texto compatible con Messages API. Revisa `MODEL` antes de lanzar al público.
- Esta versión no tiene cuentas de usuario, base de datos persistente, progreso sincronizado ni comunidad. Las reflexiones pueden ser sensibles: no les pidas a usuarios información íntima innecesaria hasta contar con avisos de privacidad, retención y medidas de seguridad adecuadas.
- Los controles de edición/publicación del prototipo original de Claude dependen del Artifact y no equivalen a un panel de administración web persistente. Usa `public/posts.json` para editar contenido en el repositorio.

## Actualizar contenido
Edita `public/posts.json` en GitHub y guarda los cambios; Vercel desplegará la versión nueva si está conectado al repositorio.
